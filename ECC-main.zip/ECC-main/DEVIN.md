# DEVIN.md — Everything Claude Code (ECC) for Devin

This document provides instructions for **Devin** (by Cognition AI) to leverage the full power of Everything Claude Code (ECC).

---

## 1. Devin Quickstart & Role Alignment

When working on any repository equipped with ECC, Devin should act as the **primary orchestrator**, adopting the specialized persona, principles, and workflows contained within this framework:

- **Immutability First**: Never mutate existing state or objects directly; always return clean, new copies.
- **TDD (Test-Driven Development)**: Write failing tests before implementation (RED -> GREEN -> REFACTOR) and maintain >80% code coverage.
- **Security-First**: Enforce input validation, parameterization, no secret leaks, and sanitization before any commit.
- **Plan Before Execute**: For non-trivial features or refactoring, produce an implementation plan before writing production code.

---

## 2. Using ECC Agents and Skills in Devin

Devin has access to a Linux sandbox with bash execution and file reading. ECC provides **68 specialized agents** in `agents/` and **286 workflow skills** in `skills/`.

### How Devin Should Consult ECC:
1. **Identify the task domain**:
   - Backend API design -> Read `skills/api-design/SKILL.md` or `skills/backend-patterns/SKILL.md`
   - Frontend / UI -> Read `skills/frontend-patterns/SKILL.md` or `skills/modern-web-guidance/SKILL.md`
   - Database / Migrations -> Read `agents/database-reviewer.md`
   - Code Review -> Read `agents/code-reviewer.md` and `skills/coding-standards/SKILL.md`
   - Security Checks -> Read `agents/security-reviewer.md` and `skills/security-review/SKILL.md`
   - E2E Testing -> Read `skills/e2e-testing/SKILL.md`
2. **Execute ECC Utility Scripts**:
   Devin can run Node.js utilities in the terminal:
   ```bash
   # Check ECC health and doctor report
   node scripts/doctor.js

   # Verify harness status
   node scripts/status.js

   # Run test suites
   node tests/run-all.js
   ```

---

## 3. Recommended Devin Workflow

```
1. RECEIVE TASK
      ↓
2. DISCOVER ECC SKILLS & RULES (Inspect `skills/`, `rules/`, `agents/`)
      ↓
3. DRAFT PLAN & TEST CASES (Follow `skills/tdd-workflow/SKILL.md`)
      ↓
4. WRITE FAILING TESTS (Red phase)
      ↓
5. IMPLEMENT SOLUTION (Green phase)
      ↓
6. CODE & SECURITY REVIEW (Consult `agents/code-reviewer.md` & `agents/security-reviewer.md`)
      ↓
7. VERIFY & RUN FULL TEST SUITE (`node tests/run-all.js` or project tests)
```

---

## 4. Key Rules Checklist for Devin

- [ ] **Small files**: Keep files focused (typically 200–400 lines, 800 max).
- [ ] **Input validation**: Never trust external data; validate at system boundaries.
- [ ] **No hardcoded secrets**: Always use environment variables or secret managers.
- [ ] **Zero lint/type errors**: Fix all type errors and lint warnings before completing the task.
