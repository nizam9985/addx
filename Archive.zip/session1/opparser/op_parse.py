import os
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts.chat import ChatPromptTemplate

# Load environment variables (expects OPENAI_API_KEY)
load_dotenv()

# LLM client (temperature optional)
chat_model = ChatOpenAI(model="gpt-4o")

# Prompt instructs exact answer format
template = (
    '''You are a helpful assistant that solves math problems and shows your work,
    Output each step, then return the final line in the format: answer = <answer here>
    Make sure 'answer' is all lowercase, with exactly one space, one equal sign and one space.''' )

human_template = "{text}"

chat_prompt = ChatPromptTemplate.from_messages([
    ("system", template),
    ("human", human_template),
])
print('------- this is without any parser')
chain = chat_prompt | chat_model 
result = chain.invoke({"text": "colors" })
print(result)
print('_________________________')

print('------- this is with output parser')
chain_str = chat_prompt | chat_model | StrOutputParser()
resultstr = chain_str.invoke({"text": "colors" })
print(resultstr)
print('_________________________')
