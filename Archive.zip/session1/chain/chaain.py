from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from dotenv import load_dotenv
load_dotenv()

prompt = ChatPromptTemplate.from_template(
    "Translate to hindi: {text}"
)
llm = ChatOpenAI(model="gpt-4o", temperature=0)
parser = StrOutputParser()

# LCEL composition with the pipe operator
chain = prompt | llm | parser

# Same APIs across sync/async/stream
print(chain.invoke({"text": "Good morning"}))  
